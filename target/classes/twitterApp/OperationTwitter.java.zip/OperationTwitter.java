package twitterApp;

import twitter4j.FilterQuery;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.StallWarning;
import twitter4j.Status;
import twitter4j.StatusDeletionNotice;
import twitter4j.StatusListener;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterStream;

public class OperationTwitter {

	public static void sendTweet(Twitter twitter,String msg){
		try {
			twitter.updateStatus(msg);
		} catch (TwitterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void receiveTweet(Twitter twitter,String user){
		
		Query query = new Query("from:"+user);
        try {
            QueryResult result = twitter.search(query);
            for (Status tweet : result.getTweets()) {
                System.out.println("text : " + tweet.getText());
            }
        } catch (TwitterException e) {
            e.printStackTrace();
        }
	}
	
	public static void readStatus(TwitterStream myTwitterStream, String filter){
		StatusListener listener = new StatusListener(){

			public void onException(Exception arg0) {
				// TODO Auto-generated method stub
				
			}

			public void onDeletionNotice(StatusDeletionNotice arg0) {
				// TODO Auto-generated method stub
				
			}

			public void onScrubGeo(long arg0, long arg1) {
				// TODO Auto-generated method stub
				
			}

			public void onStallWarning(StallWarning arg0) {
				// TODO Auto-generated method stub
				
			}

			public void onStatus(Status status) {
				System.out.println(status);
			}

			public void onTrackLimitationNotice(int arg0) {
				// TODO Auto-generated method stub
				
			}
		};
		FilterQuery query = new FilterQuery();
		String[] keywords= { filter };
		query.track(keywords);
		myTwitterStream.addListener(listener);
		myTwitterStream.filter(query);
	}
	
}
